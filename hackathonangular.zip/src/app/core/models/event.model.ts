export interface Event {
    id: string;
    name: string;
    createdBy: string;
    date:string;
    time: string;
    description:string;
    topic:string;
    link:string;
    image:string;
}