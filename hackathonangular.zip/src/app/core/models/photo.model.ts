export interface Photo {
    id: string;
    name: string;
    caption: string;
    count:string;
    image: string;
}
