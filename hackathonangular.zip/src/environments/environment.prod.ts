export const environment = {
  production: true,
  api_url: "http://localhost:8080",
};
